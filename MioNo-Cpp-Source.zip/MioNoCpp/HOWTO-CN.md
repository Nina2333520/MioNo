# MioNo C++ 版 —— 从零到 exe 的完整步骤

> 全程不用装任何开发环境。你只需要一个浏览器 + 双击两次。
> 整个过程 **约 10 分钟**（其中 5 分钟是等 GitHub 帮你编译）。

---

## 第 0 步：确认你手上有这些

- ✅ 一个 GitHub 账号（没有就去 https://github.com 注册，免费）
- ✅ 电脑上装了 Git（没有的话，**第一步就是装它**）
- ✅ 我给你的 `MioNo-Cpp-Source.zip`

**装 Git**：去 https://git-scm.com/download/win 下载，双击安装，
**一路点「Next」到结束**就行，什么都不用改。装完**重启一下文件资源管理器**（或者干脆重启电脑）。

怎么确认装好了：桌面右键，如果菜单里多出「Git Bash Here」和「Open Git GUI Here」，就装好了。

---

## 第 1 步：在 GitHub 上建一个空仓库

1. 浏览器打开 **https://github.com/new**

2. 照着填（**只有这三处要动**）：

   | 字段 | 填什么 |
   |---|---|
   | **Repository name** | `MioNo` |
   | **Description** | 随便写，可以空着 |
   | **Public / Private** | 选 **Public**（私有仓库跑 Actions 也免费，但公开更省事） |

3. ⚠️ **下面三个方框一个都不要勾**：

   - ❌ Add a README file
   - ❌ Add .gitignore
   - ❌ Choose a license

   > **为什么？** 勾了的话仓库里会先有文件，你推的时候会冲突，脚本会报错。
   > 建一个**完全空的**仓库最省事。

4. 点最下面的绿色按钮 **Create repository**

5. 建完之后页面会跳转，长这样：

   ```
   https://github.com/你的用户名/MioNo
   ```

   **把这个地址复制下来**，下一步要用。也可以直接用页面上
   `Quick setup` 那一块给你的 `https://github.com/你的用户名/MioNo.git`（多个 `.git` 也一样，脚本会自动处理）。

---

## 第 2 步：解压 + 双击推送脚本

1. 找到我给你的 **`MioNo-Cpp-Source.zip`**，右键 → **全部解压**（不要直接在里面双击！）

   解压出来是一个 **`MioNoCpp` 文件夹**，里面有：

   ```
   MioNoCpp/
   ├── push-to-github.bat     ← 双击这个
   ├── HOWTO-CN.md            ← 你正在看的这份说明
   ├── Source/                 ← C++ 代码
   ├── .github/workflows/      ← 自动编译配置
   ├── CMakeLists.txt
   └── assets/app.ico
   ```

2. **双击 `push-to-github.bat`**

3. 会出现一个黑色窗口，问你「仓库地址」

   **把第 1 步复制的地址粘贴进去**（在命令行里粘贴是**点右键**，不是 Ctrl+V）

   ```
   仓库地址: https://github.com/nina520/MioNo.git
   ```

4. 按回车，等它跑

---

## 第 3 步：登录 GitHub

第一次推送会**弹出登录窗口**（Git Credential Manager）。

推荐做法：

1. 弹窗里选 **Sign in with your browser**（用浏览器登录）
2. 浏览器自动打开 GitHub，点 **Authorize** 或 **Continue**
3. 看到绿色勾就成功了，回到黑窗口继续跑

> 如果**没弹窗**，而是在命令行里问 `Username:` / `Password:`，那就是要手动填：
> - `Username:` 填你的 GitHub 用户名
> - `Password:` **不能填账号密码**！要填 **Token**，见下面的常见问题②

---

## 第 4 步：等 GitHub 帮你编译

推送成功后，黑窗口会显示「推送成功！」并**自动帮你打开 Actions 页面**。

手动去也行：**你的仓库 → 顶部 `Actions` 标签**

你会看到：

```
Build MioNo (Windows)          ← 点左边的这个
  ● 第 1 次运行   🟡 黄色转圈   ← 正在编译，等它
```

**第一次要 4~6 分钟**（正在下载并编译 JUCE 框架，300 多 MB 的东西）。
之后你再改代码重推，有缓存了，**1~2 分钟**就跑完。

等它变成：

```
  ● 第 1 次运行   ✅ 绿色勾
```

---

## 第 5 步：下载 exe

1. **点进那次绿色的运行记录**
2. 页面滑到**最底部**
3. 找到 **Artifacts** 这一栏
4. 点 **`MioNo-win64.zip`** 下载

解压，里面是：

```
MioNo/
├── MioNo.exe        ← 双击这个
├── Source/          ← 源码（方便你对照）
└── README.md
```

**双击 `MioNo.exe` 就能用了** 🎉

---

## 常见问题

### ① 提示 `repository not found`

仓库没建，或者地址打错了。

→ 回第 1 步，去 https://github.com/new 建一个。
→ 或者检查地址：必须是 `https://github.com/你的用户名/MioNo.git` 这种格式。

### ② 提示 `Authentication failed`

**密码处不能填你的 GitHub 登录密码**（GitHub 早就不支持了），要填 **Token**。

生成 Token 的步骤：

1. 打开 **https://github.com/settings/tokens/new**
2. 照填：

   | 字段 | 填什么 |
   |---|---|
   | **Note** | `MioNo` |
   | **Expiration** | `90 days` |

3. **勾选 `repo`**（就勾最上面那个大类的复选框，下面会自动全勾上）
4. 滑到最下面，点 **Generate token**
5. 页面上会出现一串 **`ghp_` 开头**的字符

   ⚠️ **只显示这一次！** 先复制下来存着。
6. 重跑脚本，弹窗时：
   - Username：你的 GitHub 用户名
   - Password：**粘贴这串 Token**

### ③ Actions 页面报红色 ❌

点进那次失败的运行，看哪一步红了，把报错发我，我改代码。

好消息是：**CI 失败不影响你本地**，改完重推就行。

### ④ 一直卡着不动

网络问题。开个加速器/梯子再试。

### ⑤ 提示 `src refspec main does not match any`

本地还没提交成功。直接**重跑一次脚本**即可。

### ⑥ 我改了代码，怎么重新出 exe？

把新的源码文件覆盖掉旧的，**再双击一次脚本**就行了。
GitHub 会自动重新编译，还是去 Actions 页面下新的 zip。

---

## 对比一下两个版本

| | Python 版（已有） | **C++ 版（这个）** |
|---|---|---|
| 包大小 | 47 MB | **约 10~15 MB** |
| 内存占用 | 141 MB | **约 40~70 MB** |
| 启动速度 | 1~3 秒 | **0.3~1 秒** |
| ASIO | 支持 | 支持 |
| VST3 插件 | ❌ 不支持 | ✅ **支持** |
| 怎么拿到 | 我已经发你了 | 走这套流程自己编 |

两个版本**互不冲突**，Python 版你照常能用。
